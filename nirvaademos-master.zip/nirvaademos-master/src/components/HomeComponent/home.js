import React from 'react';
import './home.css';
import {logo} from '../../assets/css/img/demo.png'

const HomePage = () => {
  return (
    <div>
 <img src={logo} alt='abdc'/>

    </div>
  )
}

export default HomePage